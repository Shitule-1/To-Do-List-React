import React from "react";
import './App.css'
function ToDoItem({ item, index, toggleComplete, deleteToDo, startEditing }) {
    return (
        <div className="for_css">
        <li>
            <span
                onClick={() => toggleComplete(index)}
                style={{
                    color: item.completed ? "blue" : "black", 
                    textDecoration: item.completed ? "line-through" : "none",cursor:"pointer" 
                    }}
            ><h1 style={{color:"orangered"}}>{item.text}</h1>
                
            </span> 
            <span className="actions" >
                <button
                    onClick={() => startEditing(index)}
                    className="btn btn-sm btn-warning me-2"
                >
                    Edit
                </button>
                <button
                    onClick={() => deleteToDo(index)}
                    className="btn btn-sm btn-danger"
                >
                    &times;
                </button>
            </span>
        </li>
        </div>
    );
}

export default ToDoItem;
