import React, { useState } from 'react';
import './App.css';
import Header from './Header';
import ToDoList from './ToDoList';
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  let [todolist, setTodolist] = useState([]);
  let [editingIndex, setEditingIndex] = useState(null);
  let [editText, setEditText] = useState("");


  let saveToDoList = (event) => {
    event.preventDefault(); 
    let toName = event.target.toName.value.trim();

    // Avoid duplicate or empty items
    if (!todolist.some(item => item.text === toName) && toName !== '') {
      let finalDolist = [...todolist, { text: toName, completed: false }];
      setTodolist(finalDolist);
    } else {
      alert("Item already exists or is empty");
    }

    event.target.reset();
  };

  let toggleComplete = (index) => {
    let updatedList = todolist.map((item, i) =>
      i === index ? { ...item, completed: !item.completed } : item
    );
    setTodolist(updatedList);
  };

  // Delete a  item
  let deleteToDo = (index) => {
    let updatedList = todolist.filter((_, i) => i !== index);
    setTodolist(updatedList);
  };
  //  editing a  item
  let startEditing = (index) => {
    setEditingIndex(index);
    setEditText(todolist[index].text);
  };

  // Save  edited  item
  let saveEdit = (event) => {
    event.preventDefault();
    let updatedList = todolist.map((item, i) =>
      i === editingIndex ? { ...item, text: editText } : item
    );
    setTodolist(updatedList);
    setEditingIndex(null);
    setEditText("");
  };

  return (
    <>
      <Header title="To Do List" />
<form onSubmit={saveToDoList} className="mb-4">
  <div className="input-group">
    <input 
      type="text" 
      name="toName" 
      className="form-control" 
      placeholder="Enter a new task" 
      aria-label="To-do task"
    />
    <button className="btn btn-primary" type="submit">Add</button>
  </div>
</form>

      <ToDoList
        todolist={todolist}
        toggleComplete={toggleComplete}
        deleteToDo={deleteToDo}
        startEditing={startEditing}
      />

      {}
      {editingIndex !== null && (
        <form onSubmit={saveEdit}>
          <input className='form-control'
            type="text"
            value={editText}
            onChange={(e) => setEditText(e.target.value)}
          />
<button type="submit" className="btn btn-success me-2">Save Edit</button>
      <button type="button" className="btn btn-danger" onClick={() => setEditingIndex(null)}>Cancel</button>
        </form>
      )}
    </>
  );
}
export default App;

