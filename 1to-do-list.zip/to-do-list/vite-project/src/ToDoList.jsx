import React from 'react';
import ToDoItem from './ToDoItem';

function ToDoList({ todolist, toggleComplete, deleteToDo, startEditing }) {
  return (
    <div className="outerDiv">
      <ul className="list-group">
        {todolist.map((item, index) => (
          <ToDoItem
            key={index}
            index={index}
            item={item}
            toggleComplete={toggleComplete}
            deleteToDo={deleteToDo}
            startEditing={startEditing}
          />
        ))}
      </ul>
    </div>
  );
}

export default ToDoList;
